#include <iostream>
#include <fstream>
#include <math.h>
#include <stdlib.h>

using namespace std;

int main(int argc,char *argv[]){

    double iter_no, cm, cd, cl, angleoa, dummy;
    int iterno=atoi(argv[1]);
    int dumCounter=0;

    ifstream forceCoeffs;
    forceCoeffs.open("QoI_intermediate.dat");
    while (forceCoeffs >> iter_no >> cm >> cd >> cl >> dummy >> dummy){
      dumCounter++;
    }
    forceCoeffs.close();

    ifstream AOA;
    AOA.open("angles.dat");
    AOA >> angleoa;
    AOA.close();

    ofstream write_output;
    write_output.open("QoI.dat");
    write_output << cd << endl;
    write_output.close();

    ofstream write_plot_output;
    write_plot_output.open("../../results/iterQoI.dat", ios_base::app);
    write_plot_output << iterno <<" "<< angleoa <<" "<< cd <<" "<< cl << endl;
    write_plot_output.close();

    cout << "Iter No: " << iterno << endl;
    cout << "AOA: " << angleoa << endl;
    cout << "cl: " << cl << endl;
    cout << "cd: " << cd << endl;
    cout << "Iter No: " << iterno << endl;


    cout << "QoIs have been processed." << '\n';

}
